from future import Future

import inspect


class SplitAgent(object):


    def __init__(self):
        pass


    def split(self, input_size: int, num_chunks: int) -> Future:
        """Split input_size bytes of data into num_chunks equal chunks."""
        args = {'input_size': input_size.id if isinstance(input_size, Future) else input_size, 'num_chunks': num_chunks.id if isinstance(num_chunks, Future) else num_chunks}
        return Future(parent=inspect.stack()[1].filename, service='SplitAgent', method='split', args=args)
