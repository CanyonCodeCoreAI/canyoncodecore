from future import Future

import inspect


class IndexAgent(object):


    def __init__(self):
        pass


    def build_index(self, merged_digest: str, total_size: int) -> Future:
        """Build the final index from the merged digest."""
        args = {'merged_digest': merged_digest.id if isinstance(merged_digest, Future) else merged_digest, 'total_size': total_size.id if isinstance(total_size, Future) else total_size}
        return Future(parent=inspect.stack()[1].filename, service='IndexAgent', method='build_index', args=args)
