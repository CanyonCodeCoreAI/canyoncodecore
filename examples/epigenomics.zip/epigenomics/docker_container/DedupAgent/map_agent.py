from future import Future

import inspect


class MapAgent(object):


    def __init__(self):
        pass


    def align(self, chunk_id: str, size: int, digest: str) -> Future:
        """Align one filtered chunk, returning its post-alignment digest."""
        args = {'chunk_id': chunk_id.id if isinstance(chunk_id, Future) else chunk_id, 'size': size.id if isinstance(size, Future) else size, 'digest': digest.id if isinstance(digest, Future) else digest}
        return Future(parent=inspect.stack()[1].filename, service='MapAgent', method='align', args=args)
