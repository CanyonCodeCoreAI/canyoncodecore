from future import Future

import inspect


class FilterAgent(object):


    def __init__(self):
        pass


    def filter_contams(self, chunk_id: str, size: int) -> Future:
        """Filter contaminants out of one chunk, returning its content digest."""
        args = {'chunk_id': chunk_id.id if isinstance(chunk_id, Future) else chunk_id, 'size': size.id if isinstance(size, Future) else size}
        return Future(parent=inspect.stack()[1].filename, service='FilterAgent', method='filter_contams', args=args)
