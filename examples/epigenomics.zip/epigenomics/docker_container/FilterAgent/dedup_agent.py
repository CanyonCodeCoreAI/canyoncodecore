from future import Future

import inspect


class DedupAgent(object):


    def __init__(self):
        pass


    def merge_dedup(self, chunks: list) -> Future:
        """Merge and deduplicate every sorted chunk into one combined digest."""
        args = {'chunks': chunks.id if isinstance(chunks, Future) else chunks}
        return Future(parent=inspect.stack()[1].filename, service='DedupAgent', method='merge_dedup', args=args)
