import threading
import time
import sys

from local_controller import LocalController


def start_lc():
    controller = LocalController(port=50051)
    controller.run()


# Start local controller in background thread
lc_thread = threading.Thread(target=start_lc, daemon=True)
lc_thread.start()

# Give the LC a moment to start up
time.sleep(1)

# Run the workflow (which calls deploy() -> Flask server)
exec(open("epigenomics_workflow.py").read())
